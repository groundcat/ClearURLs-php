# ClearURLs-php
This script removes tracking elements from URLs to help protect the privacy.

A merged catalog of rules from [ClearURLs](https://github.com/ClearURLs/Rules) and locally-configured rules are used.

# Prerequisite
Run `runes_updater.php` to fetch and update rules. Set up a cron job if necessary.

# License
GNU Lesser General Public License v3.0
